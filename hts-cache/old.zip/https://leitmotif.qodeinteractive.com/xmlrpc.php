<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8" />
<link rel="profile" href="https://gmpg.org/xfn/11" />
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
<title>Page not found &#8211; Leitmotif</title>
<meta name="robots" content="max-image-preview:large" />

<script data-cfasync="false" data-pagespeed-no-defer>
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
</script>
<link rel="dns-prefetch" href="//export.qodethemes.com" />
<link rel="dns-prefetch" href="//maps.googleapis.com" />
<link rel="dns-prefetch" href="//static.zdassets.com" />
<link rel="dns-prefetch" href="//fonts.googleapis.com" />
<link rel="dns-prefetch" href="//s.w.org" />
<link rel="alternate" type="application/rss+xml" title="Leitmotif &raquo; Feed" href="https://leitmotif.qodeinteractive.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Leitmotif &raquo; Comments Feed" href="https://leitmotif.qodeinteractive.com/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/leitmotif.qodeinteractive.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.0.9"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode,e=(p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0),i.toDataURL());return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([129777,127995,8205,129778,127999],[129777,127995,8203,129778,127999])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" id="wp-block-library-css" href="https://leitmotif.qodeinteractive.com/wp-includes/css/dist/block-library/style.min.css?ver=6.0.9" type="text/css" media="all" />
<style id="global-styles-inline-css" type="text/css">
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
</style>
<link rel="stylesheet" id="titan-adminbar-styles-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/anti-spam/assets/css/admin-bar.css?ver=7.3.3" type="text/css" media="all" />
<link rel="stylesheet" id="contact-form-7-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.6.4" type="text/css" media="all" />
<link rel="stylesheet" id="rabbit_css-css" href="https://export.qodethemes.com/_toolbar/assets/css/rbt-modules.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="ppress-frontend-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/css/frontend.min.css?ver=4.3.0" type="text/css" media="all" />
<link rel="stylesheet" id="ppress-flatpickr-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/flatpickr/flatpickr.min.css?ver=4.3.0" type="text/css" media="all" />
<link rel="stylesheet" id="ppress-select2-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/select2/select2.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="swiper-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/plugins/swiper/swiper.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="qi-addons-for-elementor-grid-style-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/grid.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="qi-addons-for-elementor-helper-parts-style-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/helper-parts.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="qi-addons-for-elementor-style-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/main.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-default-style-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/style.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-modules-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/css/modules.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-dripicons-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/framework/lib/icons-pack/dripicons/dripicons.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-font_elegant-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/framework/lib/icons-pack/elegant-icons/style.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-font_awesome-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/framework/lib/icons-pack/font-awesome/css/fontawesome-all.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-ion_icons-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/framework/lib/icons-pack/ion-icons/css/ionicons.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-linea_icons-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/framework/lib/icons-pack/linea-icons/style.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-linear_icons-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/framework/lib/icons-pack/linear-icons/style.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-simple_line_icons-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/framework/lib/icons-pack/simple-line-icons/simple-line-icons.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="mediaelement-css" href="https://leitmotif.qodeinteractive.com/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.16" type="text/css" media="all" />
<link rel="stylesheet" id="wp-mediaelement-css" href="https://leitmotif.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-style-dynamic-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/css/style_dynamic.css?ver=1580823669" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-modules-responsive-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/css/modules-responsive.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-style-dynamic-responsive-css" href="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/css/style_dynamic_responsive.css?ver=1580823669" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-edge-google-fonts-css" href="https://fonts.googleapis.com/css?family=Barlow+Condensed%3A300%2C400%2C600%2C700%7CRoboto+Mono%3A300%2C400%2C600%2C700&#038;subset=latin-ext&#038;ver=1.0.0" type="text/css" media="all" />
<link rel="stylesheet" id="leitmotif-core-dashboard-style-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/leitmotif-core/core-dashboard/assets/css/core-dashboard.min.css?ver=6.0.9" type="text/css" media="all" />
<link rel="stylesheet" id="qode-zendesk-chat-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/qode-zendesk-chat//assets/main.css?ver=6.0.9" type="text/css" media="all" />
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0" id="jquery-core-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.6.5" async id="tp-tools-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.6.5" async id="revmin-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/flatpickr/flatpickr.min.js?ver=4.3.0" id="ppress-flatpickr-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/select2/select2.min.js?ver=4.3.0" id="ppress-select2-js"></script>
<link rel="https://api.w.org/" href="https://leitmotif.qodeinteractive.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://leitmotif.qodeinteractive.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://leitmotif.qodeinteractive.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 6.0.9" />
<script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		if (window.wfLogHumanRan) { return; }
		window.wfLogHumanRan = true;
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('//leitmotif.qodeinteractive.com/?wordfence_lh=1&hid=BE24C1BB3231B95EB737B2B0162C0A4E');
</script>


<script data-cfasync="false" data-pagespeed-no-defer>
	var dataLayer_content = {"pagePostType":"404-error"};
	dataLayer.push( dataLayer_content );
</script>
<script data-cfasync="false">
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5T772QJ');
</script>

<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress." />
<meta name="generator" content="Powered by Slider Revolution 6.6.5 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/cropped-favicon-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/cropped-favicon-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/cropped-favicon-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/cropped-favicon-1-270x270.png" />
<script>function setREVStartSize(e){
			//window.requestAnimationFrame(function() {
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;
				try {
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) || (e.l=="fullwidth" || e.layout=="fullwidth") ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);
					if(e.layout==="fullscreen" || e.l==="fullscreen")
						newh = Math.max(e.mh,window.RSIH);
					else{
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,
							sl;
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}
					var el = document.getElementById(e.c);
					if (el!==null && el) el.style.height = newh+"px";
					el = document.getElementById(e.c+"_wrapper");
					if (el!==null && el) {
						el.style.height = newh+"px";
						el.style.display = "block";
					}
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}
			//});
		  };</script>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 leitmotif-core-1.2 qodef-qi--no-touch qi-addons-for-elementor-1.5.4 leitmotif-ver-1.2 edgtf-grid-1400 edgtf-wide-dropdown-menu-content-in-grid edgtf-fixed-on-scroll edgtf-dropdown-animate-height edgtf-header-standard edgtf-menu-area-shadow-disable edgtf-menu-area-in-grid-shadow-disable edgtf-menu-area-border-disable edgtf-menu-area-in-grid-border-disable edgtf-logo-area-border-disable edgtf-logo-area-in-grid-border-disable edgtf-side-menu-slide-from-right edgtf-default-mobile-header edgtf-sticky-up-mobile-header edgtf-fullscreen-search edgtf-search-fade wpb-js-composer js-comp-ver-6.10.0 vc_responsive elementor-default elementor-kit-2384" itemscope itemtype="https://schema.org/WebPage">
<div class="edgtf-wrapper">
<div class="edgtf-wrapper-inner">
<div class="edgtf-fullscreen-search-holder">
<a class="edgtf-search-close edgtf-search-close-svg-path" href="javascript:void(0)">
<svg class="edgtf-close-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="36.85px" height="36.85px" viewBox="0 0 36.85 36.85" enable-background="new 0 0 36.85 36.85" xml:space="preserve">
<path d="M27.617,34.209c-0.27,0-0.521-0.104-0.709-0.295l-8.483-8.481l-8.484,8.483c-0.362,0.365-1.048,0.367-1.415,0l-4.948-4.949
	c-0.39-0.39-0.39-1.024,0-1.414l8.483-8.484l-8.483-8.482c-0.391-0.391-0.391-1.024,0-1.414l4.948-4.949
	c0.364-0.366,1.05-0.366,1.414,0l8.484,8.484l8.485-8.484c0.363-0.365,1.046-0.366,1.414,0l4.948,4.95
	c0.188,0.188,0.293,0.438,0.293,0.707c0,0.268-0.104,0.519-0.293,0.708l-8.483,8.482l8.483,8.484c0.391,0.39,0.391,1.024,0,1.414
	l-4.948,4.949C28.133,34.105,27.882,34.209,27.617,34.209z M27.617,33.209v0.5V33.209L27.617,33.209z M9.234,4.928l-4.948,4.95
	l9.19,9.189l-9.19,9.192l4.948,4.949l9.191-9.19l9.192,9.19l4.948-4.949l-9.19-9.191l9.19-9.189l-4.948-4.95l-9.192,9.191
	L9.234,4.928z" />
<rect x="14.232" y="2.404" transform="matrix(0.7026 -0.7116 0.7116 0.7026 -8.1402 18.8498)" width="8.499" height="33.52" />
<rect x="14.295" y="2.279" transform="matrix(-0.7026 -0.7116 0.7116 -0.7026 18.027 45.6112)" width="8.499" height="33.52" />
</svg> </a>
<div class="edgtf-fullscreen-search-table">
<div class="edgtf-fullscreen-search-cell">
<div class="edgtf-fullscreen-search-inner">
<form action="https://leitmotif.qodeinteractive.com/" class="edgtf-fullscreen-search-form" method="get">
<div class="edgtf-form-holder">
<div class="edgtf-form-holder-inner">
<div class="edgtf-field-holder">
<input type="text" placeholder="Search for..." name="s" class="edgtf-search-field" autocomplete="off" required />
</div>
<button type="submit" class="edgtf-search-submit edgtf-search-submit-svg-path">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
<g>
<path d="M27.78,31.25c-0.86,0-1.67-0.335-2.278-0.942l-8.055-8.054c-1.574,0.831-3.335,1.268-5.124,1.268
		c-6.037,0-10.948-4.911-10.948-10.948S6.286,1.625,12.323,1.625s10.948,4.911,10.948,10.948c0,1.79-0.437,3.551-1.268,5.125
		l8.054,8.054c1.256,1.256,1.256,3.3,0,4.556C29.449,30.915,28.641,31.25,27.78,31.25z M17.559,20.811
		c0.168,0,0.332,0.064,0.456,0.188l8.398,8.398c0.729,0.728,2.005,0.728,2.734,0c0.753-0.754,0.753-1.981,0-2.734l-8.398-8.398
		c-0.207-0.208-0.248-0.529-0.1-0.782c0.873-1.483,1.334-3.181,1.334-4.909c0-5.327-4.333-9.66-9.66-9.66
		c-5.327,0-9.66,4.333-9.66,9.66c0,5.327,4.333,9.66,9.66,9.66c1.727,0,3.425-0.461,4.909-1.334
		C17.334,20.84,17.447,20.811,17.559,20.811z" />
</g>
</svg>
</button>
<div class="edgtf-line"></div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<header class="edgtf-page-header">
<div class="edgtf-fixed-wrapper">
<div class="edgtf-menu-area edgtf-menu-center">
<div class="edgtf-vertical-align-containers">
<div class="edgtf-position-left"><div class="edgtf-position-left-inner">
<div class="edgtf-logo-wrapper">
<a itemprop="url" href="https://leitmotif.qodeinteractive.com/" style="height: 47px;">
<img itemprop="image" class="edgtf-normal-logo" src="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/logo-default.png" width="94" height="94" alt="logo" />
<img itemprop="image" class="edgtf-dark-logo" src="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/logo-default.png" width="94" height="94" alt="dark logo" /> <img itemprop="image" class="edgtf-light-logo" src="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/logo-default.png" width="94" height="94" alt="light logo" /> </a>
</div>
</div>
</div>
<div class="edgtf-position-center"><div class="edgtf-position-center-inner">
<nav class="edgtf-main-menu edgtf-drop-down edgtf-default-nav">
<ul id="menu-main-menu" class="clearfix"><li id="nav-menu-item-9" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class><span class="item_outer"><span class="item_text">home</span><i class="edgtf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-172" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://leitmotif.qodeinteractive.com/" class><span class="item_outer"><span class="item_text">Main Home</span></span></a></li>
<li id="nav-menu-item-367" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/trailers-home/" class><span class="item_outer"><span class="item_text">Trailers Home</span></span></a></li>
<li id="nav-menu-item-431" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/director-home/" class><span class="item_outer"><span class="item_text">Director Home</span></span></a></li>
<li id="nav-menu-item-575" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/interactive-links/" class><span class="item_outer"><span class="item_text">Interactive Links</span></span></a></li>
<li id="nav-menu-item-801" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/fullscreen-slider/" class><span class="item_outer"><span class="item_text">Fullscreen Slider</span></span></a></li>
<li id="nav-menu-item-579" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/movie-studio/" class><span class="item_outer"><span class="item_text">Movie Studio</span></span></a></li>
<li id="nav-menu-item-1335" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/showcase-reel/" class><span class="item_outer"><span class="item_text">Showcase Reel</span></span></a></li>
<li id="nav-menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/film-festival/" class><span class="item_outer"><span class="item_text">Film Festival</span></span></a></li>
<li id="nav-menu-item-695" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/horizontal-portfolio/" class><span class="item_outer"><span class="item_text">Horizontal Portfolio</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-10" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class><span class="item_outer"><span class="item_text">pages</span><i class="edgtf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-1031" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/about-us/" class><span class="item_outer"><span class="item_text">About Us</span></span></a></li>
<li id="nav-menu-item-2205" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/about-me/" class><span class="item_outer"><span class="item_text">About Me</span></span></a></li>
<li id="nav-menu-item-1331" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/what-we-do/" class><span class="item_outer"><span class="item_text">What We Do</span></span></a></li>
<li id="nav-menu-item-1332" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/our-crew/" class><span class="item_outer"><span class="item_text">Our Crew</span></span></a></li>
<li id="nav-menu-item-1030" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/contact-us/" class><span class="item_outer"><span class="item_text">Contact Us</span></span></a></li>
<li id="nav-menu-item-1029" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/get-in-touch/" class><span class="item_outer"><span class="item_text">Get in Touch</span></span></a></li>
<li id="nav-menu-item-1333" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/faq-page/" class><span class="item_outer"><span class="item_text">FAQ Page</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-11" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub wide"><a href="#" class><span class="item_outer"><span class="item_text">portfolio</span><i class="edgtf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-1385" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">lists</span></span></a>
<ul>
<li id="nav-menu-item-1384" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/standard/" class><span class="item_outer"><span class="item_text">Standard</span></span></a></li>
<li id="nav-menu-item-1395" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/gallery/" class><span class="item_outer"><span class="item_text">Gallery</span></span></a></li>
<li id="nav-menu-item-1413" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/pinterest/" class><span class="item_outer"><span class="item_text">Pinterest</span></span></a></li>
<li id="nav-menu-item-1400" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/interactive-scroll/" class><span class="item_outer"><span class="item_text">Interactive Scroll</span></span></a></li>
<li id="nav-menu-item-1416" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/interactive-links/" class><span class="item_outer"><span class="item_text">Interactive Links</span></span></a></li>
<li id="nav-menu-item-1404" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/portfolio-slider/" class><span class="item_outer"><span class="item_text">Portfolio Slider</span></span></a></li>
<li id="nav-menu-item-2063" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/scrolling-showcase/" class><span class="item_outer"><span class="item_text">Scrolling showcase</span></span></a></li>
<li id="nav-menu-item-1423" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/split-portfolio/" class><span class="item_outer"><span class="item_text">Horizontally Scrolling List</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1503" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">layouts</span></span></a>
<ul>
<li id="nav-menu-item-1502" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/two-columns/" class><span class="item_outer"><span class="item_text">Two Columns</span></span></a></li>
<li id="nav-menu-item-1501" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/three-columns/" class><span class="item_outer"><span class="item_text">Three Columns</span></span></a></li>
<li id="nav-menu-item-1500" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/three-columns-wide/" class><span class="item_outer"><span class="item_text">Three Columns Wide</span></span></a></li>
<li id="nav-menu-item-1499" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/four-columns/" class><span class="item_outer"><span class="item_text">Four Columns</span></span></a></li>
<li id="nav-menu-item-1498" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/four-columns-wide/" class><span class="item_outer"><span class="item_text">Four Columns Wide</span></span></a></li>
<li id="nav-menu-item-1497" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/five-columns/" class><span class="item_outer"><span class="item_text">Five Columns</span></span></a></li>
<li id="nav-menu-item-1496" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/five-columns-wide/" class><span class="item_outer"><span class="item_text">Five Columns Wide</span></span></a></li>
<li id="nav-menu-item-1523" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/six-columns-wide/" class><span class="item_outer"><span class="item_text">Six Columns Wide</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-1504" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">hover types</span></span></a>
<ul>
<li id="nav-menu-item-2130" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/rotate/" class><span class="item_outer"><span class="item_text">Rotate</span></span></a></li>
<li id="nav-menu-item-1613" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/noise/" class><span class="item_outer"><span class="item_text">Noise</span></span></a></li>
<li id="nav-menu-item-1791" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/video/" class><span class="item_outer"><span class="item_text">Video</span></span></a></li>
<li id="nav-menu-item-2255" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/follow/" class><span class="item_outer"><span class="item_text">Follow</span></span></a></li>
</ul>
</li>
<li id="nav-menu-item-174" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">singles</span></span></a>
<ul>
<li id="nav-menu-item-173" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/custom-01/" class><span class="item_outer"><span class="item_text">Custom 01</span></span></a></li>
<li id="nav-menu-item-180" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/custom-02/" class><span class="item_outer"><span class="item_text">Custom 02</span></span></a></li>
<li id="nav-menu-item-508" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/baraka/" class><span class="item_outer"><span class="item_text">Big Images</span></span></a></li>
<li id="nav-menu-item-506" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/a-separation/" class><span class="item_outer"><span class="item_text">Big Gallery</span></span></a></li>
<li id="nav-menu-item-507" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/american-honey-2/" class><span class="item_outer"><span class="item_text">Small Images</span></span></a></li>
<li id="nav-menu-item-505" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/rain-mist-calm/" class><span class="item_outer"><span class="item_text">Small Gallery</span></span></a></li>
<li id="nav-menu-item-502" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/black-stones/" class><span class="item_outer"><span class="item_text">Big Masonry</span></span></a></li>
<li id="nav-menu-item-504" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/deep-end-2/" class><span class="item_outer"><span class="item_text">Big Slider</span></span></a></li>
<li id="nav-menu-item-501" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/paloma-negra/" class><span class="item_outer"><span class="item_text">Small Masonry</span></span></a></li>
<li id="nav-menu-item-503" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/better-alone/" class><span class="item_outer"><span class="item_text">Small Slider</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-12" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class><span class="item_outer"><span class="item_text">blog</span><i class="edgtf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
<li id="nav-menu-item-747" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/right-sidebar/" class><span class="item_outer"><span class="item_text">Right Sidebar</span></span></a></li>
<li id="nav-menu-item-1034" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/left-sidebar/" class><span class="item_outer"><span class="item_text">Left Sidebar</span></span></a></li>
<li id="nav-menu-item-1033" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/no-sidebar/" class><span class="item_outer"><span class="item_text">No Sidebar</span></span></a></li>
<li id="nav-menu-item-1477" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/blog-masonry/" class><span class="item_outer"><span class="item_text">Masonry</span></span></a></li>
<li id="nav-menu-item-1435" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Singles</span></span></a>
<ul>
<li id="nav-menu-item-221" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/rough-life/" class><span class="item_outer"><span class="item_text">Standard</span></span></a></li>
<li id="nav-menu-item-1437" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/shattered-directors-cut/" class><span class="item_outer"><span class="item_text">Gallery</span></span></a></li>
<li id="nav-menu-item-1438" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/its-funny-how-the-colors-of-the-real-world-only-seem-really-real-when-you-watch-them-on-a-screen/" class><span class="item_outer"><span class="item_text">Link</span></span></a></li>
<li id="nav-menu-item-1439" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/i-simply-must-say-as-crass-as-we-are-conditioned-by-a-troubled-society-to-regard-the-word-2/" class><span class="item_outer"><span class="item_text">Quote</span></span></a></li>
<li id="nav-menu-item-1561" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/shattered-behind-the-scene-2/" class><span class="item_outer"><span class="item_text">Video</span></span></a></li>
<li id="nav-menu-item-1440" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/manny-di-pressos-road-to-fame/" class><span class="item_outer"><span class="item_text">Audio</span></span></a></li>
<li id="nav-menu-item-1565" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/the-emigrants/" class><span class="item_outer"><span class="item_text">No Sidebar</span></span></a></li>
</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-1032" class="menu-item menu-item-type-post_type menu-item-object-page  narrow"><a href="https://leitmotif.qodeinteractive.com/landing/" class><span class="item_outer"><span class="item_text">landing</span></span></a></li>
</ul> </nav>
</div>
</div>
<div class="edgtf-position-right"><div class="edgtf-position-right-inner">
<a style="margin: 0 27px 0 0;" class="edgtf-search-opener edgtf-icon-has-hover edgtf-search-opener-svg-path" href="javascript:void(0)">
<span class="edgtf-search-opener-wrapper">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
<g>
<path d="M27.78,31.25c-0.86,0-1.67-0.335-2.278-0.942l-8.055-8.054c-1.574,0.831-3.335,1.268-5.124,1.268
		c-6.037,0-10.948-4.911-10.948-10.948S6.286,1.625,12.323,1.625s10.948,4.911,10.948,10.948c0,1.79-0.437,3.551-1.268,5.125
		l8.054,8.054c1.256,1.256,1.256,3.3,0,4.556C29.449,30.915,28.641,31.25,27.78,31.25z M17.559,20.811
		c0.168,0,0.332,0.064,0.456,0.188l8.398,8.398c0.729,0.728,2.005,0.728,2.734,0c0.753-0.754,0.753-1.981,0-2.734l-8.398-8.398
		c-0.207-0.208-0.248-0.529-0.1-0.782c0.873-1.483,1.334-3.181,1.334-4.909c0-5.327-4.333-9.66-9.66-9.66
		c-5.327,0-9.66,4.333-9.66,9.66c0,5.327,4.333,9.66,9.66,9.66c1.727,0,3.425-0.461,4.909-1.334
		C17.334,20.84,17.447,20.811,17.559,20.811z" />
</g>
</svg>
</span>
</a>
<a class="edgtf-side-menu-button-opener edgtf-icon-has-hover edgtf-side-menu-button-opener-svg-path" href="javascript:void(0)">
<span class="edgtf-side-menu-icon">
<svg class="edgtf-svg-burger" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="38px" height="26px" viewBox="0 0 38 26" enable-background="new 0 0 38 26" xml:space="preserve">
<path d="M35.227,11.66H2.773c-0.818,0-1.483-0.666-1.483-1.483V2.801c0-0.818,0.666-1.484,1.483-1.484h32.454
	c0.817,0,1.482,0.666,1.482,1.484v7.375C36.709,10.994,36.044,11.66,35.227,11.66z M2.773,2.317c-0.267,0-0.483,0.217-0.483,0.484
	v7.375c0,0.267,0.217,0.483,0.483,0.483h32.454c0.267,0,0.482-0.217,0.482-0.483V2.801c0-0.267-0.217-0.484-0.482-0.484H2.773z" />
<path d="M35.227,25.592H2.773c-0.818,0-1.483-0.665-1.483-1.482v-7.375c0-0.818,0.666-1.483,1.483-1.483h32.454
	c0.817,0,1.482,0.665,1.482,1.483v7.375C36.709,24.927,36.044,25.592,35.227,25.592z M2.773,16.25c-0.267,0-0.483,0.217-0.483,0.482
	v7.375c0,0.268,0.217,0.483,0.483,0.483h32.454c0.267,0,0.482-0.217,0.482-0.483v-7.375c0-0.267-0.217-0.482-0.482-0.482H2.773z" />
<rect x="2" y="2" width="33.938" height="8.938" />
<rect x="2.031" y="15.953" width="33.938" height="8.938" />
</svg> </span>
</a>
</div>
</div>
</div>
</div>
</div>
</header>
<header class="edgtf-mobile-header">
<div class="edgtf-mobile-header-inner">
<div class="edgtf-mobile-header-holder">
<div class="edgtf-grid">
<div class="edgtf-vertical-align-containers">
<div class="edgtf-position-left"><div class="edgtf-position-left-inner">
<div class="edgtf-mobile-logo-wrapper">
<a itemprop="url" href="https://leitmotif.qodeinteractive.com/" style="height: 47px">
<img itemprop="image" src="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/logo-default.png" width="94" height="94" alt="Mobile Logo" />
</a>
</div>
</div>
</div>
<div class="edgtf-position-right"><div class="edgtf-position-right-inner">
<div class="edgtf-mobile-menu-opener edgtf-mobile-menu-opener-svg-path">
<a href="javascript:void(0)">
<span class="edgtf-mobile-menu-icon">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="38px" height="26px" viewBox="0 0 38 26" enable-background="new 0 0 38 26" xml:space="preserve">
<path d="M35.227,11.66H2.773c-0.818,0-1.483-0.666-1.483-1.483V2.801c0-0.818,0.666-1.484,1.483-1.484h32.454
	c0.817,0,1.482,0.666,1.482,1.484v7.375C36.709,10.994,36.044,11.66,35.227,11.66z M2.773,2.317c-0.267,0-0.483,0.217-0.483,0.484
	v7.375c0,0.267,0.217,0.483,0.483,0.483h32.454c0.266,0,0.482-0.217,0.482-0.483V2.801c0-0.267-0.217-0.484-0.482-0.484H2.773z" />
<path d="M35.227,25.592H2.773c-0.818,0-1.483-0.665-1.483-1.483v-7.375c0-0.818,0.666-1.483,1.483-1.483h32.454
	c0.817,0,1.482,0.665,1.482,1.483v7.375C36.709,24.927,36.044,25.592,35.227,25.592z M2.773,16.25c-0.267,0-0.483,0.217-0.483,0.483
	v7.375c0,0.267,0.217,0.483,0.483,0.483h32.454c0.266,0,0.482-0.217,0.482-0.483v-7.375c0-0.267-0.217-0.483-0.482-0.483H2.773z" />
</svg> </span>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<nav class="edgtf-mobile-nav" role="navigation" aria-label="Mobile Menu">
<div class="edgtf-grid">
<ul id="menu-main-menu-1" class><li id="mobile-menu-item-9" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" edgtf-mobile-no-link"><span>home</span></a><span class="mobile_arrow"><span class="edgtf-sub-arrow"></span></span>
<ul class="sub_menu">
<li id="mobile-menu-item-172" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://leitmotif.qodeinteractive.com/" class><span>Main Home</span></a></li>
<li id="mobile-menu-item-367" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/trailers-home/" class><span>Trailers Home</span></a></li>
<li id="mobile-menu-item-431" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/director-home/" class><span>Director Home</span></a></li>
<li id="mobile-menu-item-575" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/interactive-links/" class><span>Interactive Links</span></a></li>
<li id="mobile-menu-item-801" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/fullscreen-slider/" class><span>Fullscreen Slider</span></a></li>
<li id="mobile-menu-item-579" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/movie-studio/" class><span>Movie Studio</span></a></li>
<li id="mobile-menu-item-1335" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/showcase-reel/" class><span>Showcase Reel</span></a></li>
<li id="mobile-menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/film-festival/" class><span>Film Festival</span></a></li>
<li id="mobile-menu-item-695" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/horizontal-portfolio/" class><span>Horizontal Portfolio</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-10" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" edgtf-mobile-no-link"><span>pages</span></a><span class="mobile_arrow"><span class="edgtf-sub-arrow"></span></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1031" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/about-us/" class><span>About Us</span></a></li>
<li id="mobile-menu-item-2205" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/about-me/" class><span>About Me</span></a></li>
<li id="mobile-menu-item-1331" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/what-we-do/" class><span>What We Do</span></a></li>
<li id="mobile-menu-item-1332" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/our-crew/" class><span>Our Crew</span></a></li>
<li id="mobile-menu-item-1030" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/contact-us/" class><span>Contact Us</span></a></li>
<li id="mobile-menu-item-1029" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/get-in-touch/" class><span>Get in Touch</span></a></li>
<li id="mobile-menu-item-1333" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/faq-page/" class><span>FAQ Page</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-11" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" edgtf-mobile-no-link"><span>portfolio</span></a><span class="mobile_arrow"><span class="edgtf-sub-arrow"></span></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1385" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>lists</span></h6><span class="mobile_arrow"><span class="edgtf-sub-arrow"></span></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1384" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/standard/" class><span>Standard</span></a></li>
<li id="mobile-menu-item-1395" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/gallery/" class><span>Gallery</span></a></li>
<li id="mobile-menu-item-1413" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/pinterest/" class><span>Pinterest</span></a></li>
<li id="mobile-menu-item-1400" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/interactive-scroll/" class><span>Interactive Scroll</span></a></li>
<li id="mobile-menu-item-1416" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/interactive-links/" class><span>Interactive Links</span></a></li>
<li id="mobile-menu-item-1404" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/portfolio-slider/" class><span>Portfolio Slider</span></a></li>
<li id="mobile-menu-item-2063" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/scrolling-showcase/" class><span>Scrolling showcase</span></a></li>
<li id="mobile-menu-item-1423" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/split-portfolio/" class><span>Horizontally Scrolling List</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1503" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>layouts</span></h6><span class="mobile_arrow"><span class="edgtf-sub-arrow"></span></span>
<ul class="sub_menu">
<li id="mobile-menu-item-1502" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/two-columns/" class><span>Two Columns</span></a></li>
<li id="mobile-menu-item-1501" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/three-columns/" class><span>Three Columns</span></a></li>
<li id="mobile-menu-item-1500" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/three-columns-wide/" class><span>Three Columns Wide</span></a></li>
<li id="mobile-menu-item-1499" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/four-columns/" class><span>Four Columns</span></a></li>
<li id="mobile-menu-item-1498" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/four-columns-wide/" class><span>Four Columns Wide</span></a></li>
<li id="mobile-menu-item-1497" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/five-columns/" class><span>Five Columns</span></a></li>
<li id="mobile-menu-item-1496" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/five-columns-wide/" class><span>Five Columns Wide</span></a></li>
<li id="mobile-menu-item-1523" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/six-columns-wide/" class><span>Six Columns Wide</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-1504" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>hover types</span></h6><span class="mobile_arrow"><span class="edgtf-sub-arrow"></span></span>
<ul class="sub_menu">
<li id="mobile-menu-item-2130" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/rotate/" class><span>Rotate</span></a></li>
<li id="mobile-menu-item-1613" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/noise/" class><span>Noise</span></a></li>
<li id="mobile-menu-item-1791" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/video/" class><span>Video</span></a></li>
<li id="mobile-menu-item-2255" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/portfolio/follow/" class><span>Follow</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-174" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>singles</span></h6><span class="mobile_arrow"><span class="edgtf-sub-arrow"></span></span>
<ul class="sub_menu">
<li id="mobile-menu-item-173" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/custom-01/" class><span>Custom 01</span></a></li>
<li id="mobile-menu-item-180" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/custom-02/" class><span>Custom 02</span></a></li>
<li id="mobile-menu-item-508" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/baraka/" class><span>Big Images</span></a></li>
<li id="mobile-menu-item-506" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/a-separation/" class><span>Big Gallery</span></a></li>
<li id="mobile-menu-item-507" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/american-honey-2/" class><span>Small Images</span></a></li>
<li id="mobile-menu-item-505" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/rain-mist-calm/" class><span>Small Gallery</span></a></li>
<li id="mobile-menu-item-502" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/black-stones/" class><span>Big Masonry</span></a></li>
<li id="mobile-menu-item-504" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/deep-end-2/" class><span>Big Slider</span></a></li>
<li id="mobile-menu-item-501" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/paloma-negra/" class><span>Small Masonry</span></a></li>
<li id="mobile-menu-item-503" class="menu-item menu-item-type-post_type menu-item-object-portfolio-item "><a href="https://leitmotif.qodeinteractive.com/portfolio-item/better-alone/" class><span>Small Slider</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-12" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" edgtf-mobile-no-link"><span>blog</span></a><span class="mobile_arrow"><span class="edgtf-sub-arrow"></span></span>
<ul class="sub_menu">
<li id="mobile-menu-item-747" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/right-sidebar/" class><span>Right Sidebar</span></a></li>
<li id="mobile-menu-item-1034" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/left-sidebar/" class><span>Left Sidebar</span></a></li>
<li id="mobile-menu-item-1033" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/no-sidebar/" class><span>No Sidebar</span></a></li>
<li id="mobile-menu-item-1477" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/blog-masonry/" class><span>Masonry</span></a></li>
<li id="mobile-menu-item-1435" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Singles</span></h6><span class="mobile_arrow"><span class="edgtf-sub-arrow"></span></span>
<ul class="sub_menu">
<li id="mobile-menu-item-221" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/rough-life/" class><span>Standard</span></a></li>
<li id="mobile-menu-item-1437" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/shattered-directors-cut/" class><span>Gallery</span></a></li>
<li id="mobile-menu-item-1438" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/its-funny-how-the-colors-of-the-real-world-only-seem-really-real-when-you-watch-them-on-a-screen/" class><span>Link</span></a></li>
<li id="mobile-menu-item-1439" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/i-simply-must-say-as-crass-as-we-are-conditioned-by-a-troubled-society-to-regard-the-word-2/" class><span>Quote</span></a></li>
<li id="mobile-menu-item-1561" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/shattered-behind-the-scene-2/" class><span>Video</span></a></li>
<li id="mobile-menu-item-1440" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/manny-di-pressos-road-to-fame/" class><span>Audio</span></a></li>
<li id="mobile-menu-item-1565" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://leitmotif.qodeinteractive.com/the-emigrants/" class><span>No Sidebar</span></a></li>
</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-1032" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://leitmotif.qodeinteractive.com/landing/" class><span>landing</span></a></li>
</ul> </div>
</nav>
</div>
</header>
<a id="edgtf-back-to-top" href="#">
<span class="edgtf-icon-stack">
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="38px" height="38px" viewBox="0 0 38 38" enable-background="new 0 0 38 38" xml:space="preserve">
<path fill="#231F20" d="M33.426,18.425L21.079,6.078c-1.085-1.085-3.119-1.065-4.14,0L4.592,18.424
				c-0.551,0.552-0.867,1.309-0.867,2.08c0,0.77,0.308,1.501,0.867,2.061l1.415,1.416c1.065,1.111,3.079,1.104,4.128,0.008l4.723-4.707
				V31.43c0,1.551,1.259,2.719,2.928,2.719h2.428c1.669,0,2.929-1.168,2.929-2.719V19.282l4.715,4.698
				c1.058,1.104,3.037,1.117,4.146,0.009l1.43-1.431c0.543-0.566,0.842-1.295,0.842-2.054S33.969,18.991,33.426,18.425z" style="
			"></path>
<path fill="#231F20" d="M33.426,18.425L21.079,6.078c-1.085-1.085-3.119-1.065-4.14,0L4.592,18.424
				c-0.551,0.552-0.867,1.309-0.867,2.08c0,0.77,0.308,1.501,0.867,2.061l1.415,1.416c1.065,1.111,3.079,1.104,4.128,0.008l4.723-4.707
				V31.43c0,1.551,1.259,2.719,2.928,2.719h2.428c1.669,0,2.929-1.168,2.929-2.719V19.282l4.715,4.698
				c1.058,1.104,3.037,1.117,4.146,0.009l1.43-1.431c0.543-0.566,0.842-1.295,0.842-2.054S33.969,18.991,33.426,18.425z" style="
			"></path></svg> </span>
</a>
<div class="edgtf-content" style="margin-top: -104px">
<div class="edgtf-content-inner"> <div class="edgtf-page-not-found">
<h1 class="edgtf-404-title">
404 </h1>
<h3 class="edgtf-404-subtitle">
Page not found </h3>
<p class="edgtf-404-text">
Oops! The page you are looking for does not exist. It might have been moved or deleted. </p>
<a itemprop="url" href="https://leitmotif.qodeinteractive.com/" target="_self" class="edgtf-btn edgtf-btn-medium edgtf-btn-box"> <span class="edgtf-btn-text">Back to home</span> </a> </div>
</div>
</div>
</div>
</div>
<section class="edgtf-side-menu">
<a class="edgtf-close-side-menu edgtf-close-side-menu-svg-path" href="#">
<svg class="edgtf-close-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="36.85px" height="36.85px" viewBox="0 0 36.85 36.85" enable-background="new 0 0 36.85 36.85" xml:space="preserve">
<path d="M27.617,34.209c-0.27,0-0.521-0.104-0.709-0.295l-8.483-8.481l-8.484,8.483c-0.362,0.365-1.048,0.367-1.415,0l-4.948-4.949
	c-0.39-0.39-0.39-1.024,0-1.414l8.483-8.484l-8.483-8.482c-0.391-0.391-0.391-1.024,0-1.414l4.948-4.949
	c0.364-0.366,1.05-0.366,1.414,0l8.484,8.484l8.485-8.484c0.363-0.365,1.046-0.366,1.414,0l4.948,4.95
	c0.188,0.188,0.293,0.438,0.293,0.707c0,0.268-0.104,0.519-0.293,0.708l-8.483,8.482l8.483,8.484c0.391,0.39,0.391,1.024,0,1.414
	l-4.948,4.949C28.133,34.105,27.882,34.209,27.617,34.209z M27.617,33.209v0.5V33.209L27.617,33.209z M9.234,4.928l-4.948,4.95
	l9.19,9.189l-9.19,9.192l4.948,4.949l9.191-9.19l9.192,9.19l4.948-4.949l-9.19-9.191l9.19-9.189l-4.948-4.95l-9.192,9.191
	L9.234,4.928z" />
<rect x="14.232" y="2.404" transform="matrix(0.7026 -0.7116 0.7116 0.7026 -8.1402 18.8498)" width="8.499" height="33.52" />
<rect x="14.295" y="2.279" transform="matrix(-0.7026 -0.7116 0.7116 -0.7026 18.027 45.6112)" width="8.499" height="33.52" />
</svg> </a>
<div class="edgtf-side-menu-inner">
<div id="media_image-4" class="widget edgtf-sidearea widget_media_image"><a href="https://leitmotif.qodeinteractive.com/"><img width="133" height="133" src="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/side-area-logo-01.png" class="image wp-image-2105  attachment-full size-full" alt="a" loading="lazy" style="max-width: 100%; height: auto;" /></a></div><div class="widget edgtf-separator-widget"><div class="edgtf-separator-holder clearfix  edgtf-separator-center edgtf-separator-normal">
<div class="edgtf-separator" style="border-style: solid;margin-top: 5px"></div>
</div>
</div><div id="media_image-3" class="widget edgtf-sidearea widget_media_image"><a href="https://leitmotif.qodeinteractive.com/"><img width="393" height="108" src="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/side-area-logo-02.png" class="image wp-image-2106  attachment-full size-full" alt="a" loading="lazy" style="max-width: 100%; height: auto;" srcset="https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/side-area-logo-02.png 393w, https://leitmotif.qodeinteractive.com/wp-content/uploads/2019/10/side-area-logo-02-300x82.png 300w" sizes="(max-width: 393px) 100vw, 393px" /></a></div><div class="widget edgtf-separator-widget"><div class="edgtf-separator-holder clearfix  edgtf-separator-center edgtf-separator-normal">
<div class="edgtf-separator" style="border-style: solid;margin-top: 15px"></div>
</div>
</div><div id="text-5" class="widget edgtf-sidearea widget_text"> <div class="textwidget"><p>Apparently we had reached a great height in the atmosphere, for the sky was a dead black, and the stars had ceased.</p>
</div>
</div> <a class="edgtf-social-icon-widget-holder edgtf-icon-has-hover edgtf-icon-has-hollow-effect" style="font-size: 25px;margin: 12px 0 0;" href="https://www.facebook.com/QodeInteractive/" target="_blank">
<span>fb.</span>
</a>
<a class="edgtf-social-icon-widget-holder edgtf-icon-has-hover edgtf-icon-has-hollow-effect" style="font-size: 25px;margin: 12px 10px 0;" href="https://twitter.com/QodeInteractive" target="_blank">
<span>tw.</span>
</a>
<a class="edgtf-social-icon-widget-holder edgtf-icon-has-hover edgtf-icon-has-hollow-effect" style="font-size: 25px;margin: 12px 0 0;" href="https://www.instagram.com/qodeinteractive/" target="_blank">
<span>ig.</span>
</a>
</div>
</section>
<script>
			window.RS_MODULES = window.RS_MODULES || {};
			window.RS_MODULES.modules = window.RS_MODULES.modules || {};
			window.RS_MODULES.waiting = window.RS_MODULES.waiting || [];
			window.RS_MODULES.defered = false;
			window.RS_MODULES.moduleWaiting = window.RS_MODULES.moduleWaiting || {};
			window.RS_MODULES.type = 'compiled';
		</script>
<div class="rbt-toolbar" data-theme="Leitmotif" data-featured data-button-position="75%" data-button-horizontal="right" data-button-alt="no"></div>


<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5T772QJ" height="0" width="0" style="display:none;visibility:hidden" aria-hidden="true"></iframe></noscript>
<link rel="stylesheet" id="rs-plugin-settings-css" href="https://leitmotif.qodeinteractive.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.6.5" type="text/css" media="all" />
<style id="rs-plugin-settings-inline-css" type="text/css">
#rs-demo-id {}
</style>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.6.4" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/leitmotif.qodeinteractive.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.6.4" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://export.qodethemes.com/_toolbar/assets/js/rbt-modules.js?ver=6.0.9" id="rabbit_js-js"></script>
<script type="text/javascript" id="ppress-frontend-script-js-extra">
/* <![CDATA[ */
var pp_ajax_form = {"ajaxurl":"https:\/\/leitmotif.qodeinteractive.com\/wp-admin\/admin-ajax.php","confirm_delete":"Are you sure?","deleting_text":"Deleting...","deleting_error":"An error occurred. Please try again.","nonce":"ebbeb5dbf2","disable_ajax_form":"false","is_checkout":"0","is_checkout_tax_enabled":"0"};
/* ]]> */
</script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/wp-user-avatar/assets/js/frontend.min.js?ver=4.3.0" id="ppress-frontend-script-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/duracelltomi-google-tag-manager/js/gtm4wp-form-move-tracker.js?ver=1.16.1" id="gtm4wp-form-move-tracker-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.1" id="jquery-ui-core-js"></script>
<script type="text/javascript" id="qi-addons-for-elementor-script-js-extra">
/* <![CDATA[ */
var qodefQiAddonsGlobal = {"vars":{"adminBarHeight":0,"iconArrowLeft":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0.5\" y1=\"16\" x2=\"33.5\" y2=\"16\"\/><line x1=\"0.3\" y1=\"16.5\" x2=\"16.2\" y2=\"0.7\"\/><line x1=\"0\" y1=\"15.4\" x2=\"16.2\" y2=\"31.6\"\/><\/svg>","iconArrowRight":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0\" y1=\"16\" x2=\"33\" y2=\"16\"\/><line x1=\"17.3\" y1=\"0.7\" x2=\"33.2\" y2=\"16.5\"\/><line x1=\"17.3\" y1=\"31.6\" x2=\"33.5\" y2=\"15.4\"\/><\/svg>","iconClose":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 9.1 9.1\" xml:space=\"preserve\"><g><path d=\"M8.5,0L9,0.6L5.1,4.5L9,8.5L8.5,9L4.5,5.1L0.6,9L0,8.5L4,4.5L0,0.6L0.6,0L4.5,4L8.5,0z\"\/><\/g><\/svg>"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/js/main.min.js?ver=6.0.9" id="qi-addons-for-elementor-script-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.13.1" id="jquery-ui-tabs-js"></script>
<script type="text/javascript" id="mediaelement-core-js-before">
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.16" id="mediaelement-core-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=6.0.9" id="mediaelement-migrate-js"></script>
<script type="text/javascript" id="mediaelement-js-extra">
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=6.0.9" id="wp-mediaelement-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/jquery.appear.js?ver=6.0.9" id="appear-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/modernizr.min.js?ver=6.0.9" id="modernizr-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/owl.carousel.min.js?ver=6.0.9" id="owl-carousel-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/jquery.waypoints.min.js?ver=6.0.9" id="waypoints-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/fluidvids.min.js?ver=6.0.9" id="fluidvids-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/perfect-scrollbar.jquery.min.js?ver=6.0.9" id="perfect-scrollbar-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/ScrollToPlugin.min.js?ver=6.0.9" id="scroll-to-plugin-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/parallax.min.js?ver=6.0.9" id="parallax-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/jquery.waitforimages.js?ver=6.0.9" id="waitforimages-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/jquery.prettyPhoto.js?ver=6.0.9" id="prettyphoto-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/jquery.easing.1.3.js?ver=6.0.9" id="jquery-easing-1.3-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=6.10.0" id="isotope-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6" id="swiper-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/inc/masonry/assets/js/plugins/packery-mode.pkgd.min.js?ver=6.0.9" id="packery-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/TweenMax.min.js?ver=6.0.9" id="tweenMax-js"></script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules/plugins/jquery.mousewheel.min.js?ver=6.0.9" id="mousewheel-js"></script>
<script type="text/javascript" src="//maps.googleapis.com/maps/api/js?key=AIzaSyCJyNVBBHStm1myzUxVu9sNvdxMuI6MP9o&#038;ver=6.0.9" id="leitmotif-edge-google-map-api-js"></script>
<script type="text/javascript" id="leitmotif-edge-modules-js-extra">
/* <![CDATA[ */
var edgtfGlobalVars = {"vars":{"edgtfAddForAdminBar":0,"edgtfElementAppearAmount":-100,"edgtfAjaxUrl":"https:\/\/leitmotif.qodeinteractive.com\/wp-admin\/admin-ajax.php","sliderNavPrevArrow":"prev","sliderNavNextArrow":"next","ppExpand":"Expand the image","ppNext":"Next","ppPrev":"Previous","ppClose":"Close","edgtfStickyHeaderHeight":0,"edgtfStickyHeaderTransparencyHeight":90,"edgtfTopBarHeight":0,"edgtfLogoAreaHeight":0,"edgtfMenuAreaHeight":104,"edgtfMobileHeaderHeight":70}};
var edgtfPerPageVars = {"vars":{"edgtfMobileHeaderHeight":70,"edgtfStickyScrollAmount":0,"edgtfHeaderTransparencyHeight":104,"edgtfHeaderVerticalWidth":0}};
/* ]]> */
</script>
<script type="text/javascript" src="https://leitmotif.qodeinteractive.com/wp-content/themes/leitmotif/assets/js/modules.min.js?ver=6.0.9" id="leitmotif-edge-modules-js"></script>
<script type="text/javascript" src="https://static.zdassets.com/ekr/snippet.js?key=af3078fd-a5ae-40da-bee0-e589b98c8603&#038;ver=6.0.9" id="ze-snippet"></script><script type="text/javascript">
						zE(function(){
							$zopim(function(){
								var isChatEnabled = sessionStorage.getItem("qodeChatEnabled"),
									appearingTime = 15000;
								
								if(isChatEnabled !== "no" && window.innerWidth > 1024) {
									setTimeout(function(){
										$zopim.livechat.window.show();
										
										 $zopim.livechat.window.onHide(function(){
										    sessionStorage.setItem("qodeChatEnabled", "no");
										 });
									}, appearingTime);
								}
							});
						});
						</script></body>
</html>